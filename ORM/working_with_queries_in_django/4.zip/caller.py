import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import Author, Book, Review

# Create and check models


def find_books_by_genre_and_language(book_genre, book_language):
    books = Book.objects.filter(genre=book_genre, language=book_language)
    return books


def find_authors_nationalities():
    authors = Author.objects.exclude(nationality=None)
    return '\n'.join(f"{author.first_name} {author.last_name} is {author.nationality}" for author in authors)


def order_books_by_year():
    books = Book.objects.all().order_by('publication_year', 'title')
    return '\n'.join(f"{book.publication_year} year: {book.title} by {book.author}" for book in books)


def delete_review_by_id(review_id):
    review = Review.objects.get(id=review_id)
    review.delete()
    return f"Review by {review.reviewer_name} was deleted"


