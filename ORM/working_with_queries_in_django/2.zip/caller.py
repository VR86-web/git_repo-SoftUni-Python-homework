import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import Author, Book, Review

# Create and check models


def find_books_by_genre_and_language(book_genre, book_language):
    books = Book.objects.filter(genre=book_genre, language=book_language)
    return books


def find_authors_nationalities():
    authors = Author.objects.exclude(nationality=None)
    return '\n'.join(f"{author.first_name} {author.last_name} is {author.nationality}" for author in authors)


