import os
import django


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Astronaut, Spacecraft, Mission
from django.db.models import Q, Count


# Create queries within functions


def get_astronauts(search_string=None):
    if search_string is None:
        return ""

    astronaut = Astronaut.objects.filter(
        Q(name__icontains=search_string)
            |
        Q(phone_number__icontains=search_string)
    ).order_by('name')

    if not astronaut.exists():
        return ''

    result = []
    for a in astronaut:
        status = "Active" if a.is_active else "Inactive"
        result.append(f"Astronaut: {a.name}, phone number: {a.phone_number}, status: {status}")

    return "\n".join(result)


def get_top_astronaut():
    top_astronauts = Astronaut.objects.annotate(num_of_missions=Count('mission')).order_by(
        '-num_of_missions', 'phone_number')

    if not top_astronauts.exists() or top_astronauts.first().num_of_missions == 0:
        return "No data."

    top_astronaut = top_astronauts.first()

    return f"Top Astronaut: {top_astronaut.name} with {top_astronaut.num_of_missions} missions."


def get_top_commander():
    astronauts = Astronaut.objects.annotate(num_of_commanded_missions=Count('missions_as_commander')).order_by(
        '-num_of_commanded_missions', 'phone_number')

    if not astronauts.exists() or astronauts.first().num_of_commanded_missions == 0:
        return "No data."

    top_commander = astronauts.first()

    return f"Top Commander: {top_commander.name} with {top_commander.num_of_commanded_missions} commanded missions."




