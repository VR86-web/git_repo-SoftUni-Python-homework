from django.db import models


class MealTypeChoices(models.TextChoices):
    BREAKFAST = 'Breakfast', 'Breakfast',
    LUNCH = 'Lunch', 'Lunch',
    DINNER = 'Dinner', 'Dinner',
    SNACK = 'Snack', 'Snack'

