import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models

from django.db.models import Sum
from main_app.models import Product, Category, Customer, Order, OrderProduct


# Create and run queries

def product_quantity_ordered():
    result = []
    orders = Product.objects.annotate(total=Sum('orderproduct__quantity')).values('name', 'total').order_by('-total')

    for order in orders:
        result.append(f"Quantity ordered of {orders['name']}: {order['total']}")

    return '\n'.join(result)
